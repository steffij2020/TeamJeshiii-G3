import React from 'react';
import { StyleSheet, View, Image, Dimensions, Text, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Import Ionicons
import { useNavigation } from '@react-navigation/native'; // Import useNavigation hook

const Brands = ({ navigation }) => {
  const handleBrandPress = (brandName) => {
    console.log(`Pressed ${brandName}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.titleBar}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Image source={require('../assets/logo2.png')} style={styles.logo} />
          <Text style={styles.title}>Shop</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Cart')}>
          <Ionicons name="cart-outline" size={30} color="black" style={styles.shoppingCartIcon} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView}>
        <View style={styles.brandsContainer}>
          <Text style={styles.brandsTitle}>Brands</Text>
          <View style={styles.brandList}>
            <TouchableOpacity
              style={styles.brandButton}
              onPress={() => navigation.navigate('Charlotte')}>
              <Text style={[styles.brandButtonText, { color: '#666' }]}>Charlotte Folk</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.brandButton}
              onPress={() => navigation.navigate('Hooligans')}>
              <Text style={[styles.brandButtonText, { color: '#666' }]}>Hooligans</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.brandButton}
              onPress={() => navigation.navigate('Mnla')}>
              <Text style={[styles.brandButtonText, { color: '#666' }]}>MN+LA</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.brandButton}
              onPress={() => navigation.navigate('Offset')}>
              <Text style={[styles.brandButtonText, { color: '#666' }]}>Offset</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.brandButton}
              onPress={() => navigation.navigate('Toughwave')}>
              <Text style={[styles.brandButtonText, { color: '#666' }]}>Toughwave</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <Image source={require('../assets/home.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Brands')}>
          <Image source={require('../assets/tshirt.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Image source={require('../assets/user.png')} style={styles.logo} />
        </TouchableOpacity>
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  titleBar: {
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 20,
    paddingHorizontal: 10,
    flexDirection: 'row',
    justifyContent: 'space-between', // Align elements with space between
    alignItems: 'center',
  },
  shoppingCartIcon: {
    width: 30,
    height: 30,
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  title: {
    fontSize: 15,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  brandsContainer: {
    marginTop: 50,
    paddingHorizontal: 10,
    alignItems: 'center',
  },
  brandsTitle: {
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333', // Dark color for the title
  },
  brandList: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginVertical: 15,
    color: '#808080', // Light background color for buttons
  },
  brandButtonText: {
    fontSize: 25,
    fontWeight: 'bold',
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 10,
    paddingHorizontal: 20,
    position: 'absolute',
    bottom: 0,
  },
  scrollView: {
    flex: 1,
    width: '95%',
    marginTop: 20,
    marginBottom: 50, // Adjust according to your needs
  },
});

export default Brands;
