import React from 'react';
import { StyleSheet, View, Image, Dimensions, Text, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Import Ionicons
import { useNavigation } from '@react-navigation/native'; // Import useNavigation hook
import { useCart } from './CartContext'; // Import useCart hook

const productData = [
  { id: 1, image: require('../assets/hooligans1.jpg'), name: '96 Sweater ', price: '1,290', screen: 'hooligans1' },
  { id: 2, image: require('../assets/hooligans2.png'), name: '96 Hoodie ', price: '1,490', screen: 'hooligans2' },
  { id: 3, image: require('../assets/hooligans3.png'), name: '96 Sweater ', price: '1,290', screen: 'hooligans3' },
  { id: 4, image: require('../assets/hooligans4.png'), name: '96 Cropped Hoodie ', price: '990', screen: 'hooligans4' },
  { id: 5, image: require('../assets/hooligans5.png'), name: '96 Pants ', price: '950', screen: 'hooligans5' },
  { id: 6, image: require('../assets/hooligans6.jpg'), name: 'Cf City Tee ', price: '890', screen: 'hooligans6' }
];

const ProductItem = ({ item, onPress }) => {
  return (
    <TouchableOpacity onPress={() => onPress(item)}>
      <View style={styles.productItem}>
        <Image source={item.image} style={styles.productImage} />
        <Text style={styles.productName}>{item.name}</Text>
        <Text style={styles.productPrice}>{item.price}</Text>
      </View>
    </TouchableOpacity>
  );
};

const Hooligans = () => {
  const navigation = useNavigation(); // Use useNavigation hook
  const { addToCart } = useCart(); // Use useCart hook

  const handlePress = (item) => {
    navigation.navigate(item.screen, { item });
  };

  const handleCartPress = () => {
    navigation.navigate('Cart');
  };

  const handleAddToCart = (product) => {
    addToCart(product);
  };

  return (
    <View style={styles.container}>
      <View style={styles.titleBar}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Image source={require('../assets/logo2.png')} style={styles.logo} />
        </View>
        <TouchableOpacity onPress={handleCartPress}>
          <Ionicons name="cart-outline" size={30} color="black" style={styles.shoppingCartIcon} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView}>
        <Text style={styles.newArrivalsText}>Hooligans</Text>
        <View style={styles.productContainer}>
          {productData.map((product) => (
            <ProductItem key={product.id} item={product} onPress={handlePress} />
          ))}
        </View>
      </ScrollView>

      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <Image source={require('../assets/home.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Brands')}>
          <Image source={require('../assets/tshirt.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Image source={require('../assets/user.png')} style={styles.logo} />
        </TouchableOpacity>
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  titleBar: {
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 20,
    paddingHorizontal: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  shoppingCartIcon: {
    width: 30,
    height: 30,
  },
  newArrivalsText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  productContainer: {
    flexDirection: 'column',
    alignItems: 'center',
    marginBottom: 20,
  },
  productItem: {
    alignItems: 'center',
    margin: 5,
  },
  productImage: {
    width: (Dimensions.get('window').width - 40) / 1,
    height: (Dimensions.get('window').width - 40) / 1,
  },
  productName: {
    fontSize: 16,
    marginTop: 5,
  },
  productPrice: {
    fontSize: 14,
    color: '#888',
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 10,
    paddingHorizontal: 20,
    position: 'absolute',
    bottom: 0,
  },
  scrollView: {
    flex: 1,
    width: '95%',
    marginTop: 20,
    marginBottom: 50,
  },
});


export default Hooligans;
