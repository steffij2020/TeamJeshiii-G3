import { View, Text, Pressable, Image } from 'react-native';
import { LinearGradient } from "expo-linear-gradient";

const COLORS = {
  primary: "#3D84B8",
  secondary: "#DEC6D3",
  white: "#FFFFFF",
  black: "#000000" // Add black color
};

// Mock Button component
const Button = ({ title, onPress, style }) => (
  <Pressable onPress={onPress} style={{ padding: 12, backgroundColor: COLORS.black, borderRadius: 8, ...style }}>
    <Text style={{ color: COLORS.white, textAlign: 'center', fontSize: 18 }}>{title}</Text>
  </Pressable>
);


const Welcome = ({ navigation }) => {
    return (
        <LinearGradient
            style={{
                flex: 1
            }}
            colors={[COLORS.black, COLORS.white]} // Change gradient colors to black and white
        >
            <View style={{ flex: 1 }}>
                <View>
                   <Image
                        source={require("../assets/1.png")}
                        style={{
                            height: 100,
                            width: 100,
                            borderRadius: 20,
                            position: "absolute",
                            top: 10,
                            transform: [
                                { translateX: 20 },
                                { translateY: 50 },
                                { rotate: "-15deg" }
                            ]
                        }}
                    />

                    <Image
                        source={require("../assets/2.png")}
                        style={{
                            height: 100,
                            width: 100,
                            borderRadius: 20,
                            position: "absolute",
                            top: -30,
                            left: 100,
                            transform: [
                                { translateX: 50 },
                                { translateY: 50 },
                                { rotate: "-5deg" }
                            ]
                        }}
                    />

                    <Image
                        source={require("../assets/3.png")}
                        style={{
                            width: 100,
                            height: 100,
                            borderRadius: 20,
                            position: "absolute",
                            top: 130,
                            left: -50,
                            transform: [
                                { translateX: 50 },
                                { translateY: 50 },
                                { rotate: "15deg" }
                            ]
                        }}
                    />

                    <Image
                        source={require("../assets/4.png")}
                        style={{
                            height: 200,
                            width: 200,
                            borderRadius: 20,
                            position: "absolute",
                            top: 110,
                            left: 100,
                            transform: [
                                { translateX: 50 },
                                { translateY: 50 },
                                { rotate: "-15deg" }
                            ]
                        }}
                    />






                </View>

                {/* Content */}
                <View style={{
                    paddingHorizontal: 22,
                    position: "absolute",
                    top: 400,
                    width: "100%"
                }}>
                    <Text style={{
                        fontSize: 50,
                        fontWeight: "800",
                        color: COLORS.white
                    }}>Let's Get </Text>
                    <Text style={{
                        fontSize: 46,
                        fontWeight: "800",
                        color: COLORS.white
                    }}>Started</Text>

                    <View style={{ marginVertical: 22 }}>
                        <Text style={{
                            fontSize: 16,
                            color: COLORS.white,
                            marginVertical: 4
                        }}>Discover Style, Shop Locally:</Text>
                        <Text style={{
                            fontSize: 16,
                            color: COLORS.white,
                        }}>Hauly Grail - Your Fashion Destination</Text>
                    </View>

                    <Button
                        title="Sign Up"
                        onPress={() => navigation.navigate("Signup")}
                        style={{
                            marginTop: 22,
                            width: "100%"
                        }}
                    />

                    <View style={{
                        flexDirection: "row",
                        marginTop: 12,
                        justifyContent: "center"
                    }}>
                        <Text style={{
                            fontSize: 16,
                            color: COLORS.black
                        }}>Already have an account ?</Text>
                        <Pressable
                            onPress={() => navigation.navigate("Login")}
                        >
                            <Text style={{
                                fontSize: 16,
                                color: COLORS.black,
                                fontWeight: "bold",
                                marginLeft: 4
                            }}>Login</Text>
                        </Pressable>

                    </View>
                </View>
            </View>
        </LinearGradient>
    )
}

export default Welcome;