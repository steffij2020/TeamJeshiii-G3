import React from 'react';
import { StyleSheet, View, Image, Dimensions, Text, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Import Ionicons
import { useNavigation } from '@react-navigation/native'; // Import useNavigation hook
import { useCart } from './CartContext';

const productData = [
  { id: 1, image: require('../assets/offset1.png'), name: 'Designer Frames ', price: '1,200', screen: 'offset1' },
  { id: 2, image: require('../assets/offset2.png'), name: 'Tyson S/S ', price: '650', screen: 'offset2' },
  { id: 3, image: require('../assets/offset3.png'), name: 'Ribbed Tank Top ', price: '350', screen: 'offset3' },
  { id: 4, image: require('../assets/offset4.png'), name: 'Gradient Arc ', price: '1,100', screen: 'offset4' },
  { id: 5, image: require('../assets/offset5.png'), name: 'SLP Baby Tee ', price: '550', screen: 'offset5' },
  { id: 6, image: require('../assets/offset6.png'), name: 'SLE Baby Tee ', price: '550', screen: 'offset6' }
];

const ProductItem = ({ item, onPress }) => {
  return (
    <TouchableOpacity onPress={() => onPress(item)}>
      <View style={styles.productItem}>
        <Image source={item.image} style={styles.productImage} />
        <Text style={styles.productName}>{item.name}</Text>
        <Text style={styles.productPrice}>{item.price}</Text>
      </View>
    </TouchableOpacity>
  );
};

const Offset = () => {
  const navigation = useNavigation();
  const { addToCart } = useCart();

  const handlePress = (item) => {
    navigation.navigate(item.screen, { item });
  };

  const handleCartPress = () => {
    navigation.navigate('Cart');
  };

  return (
    <View style={styles.container}>
      <View style={styles.titleBar}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Image source={require('../assets/logo2.png')} style={styles.logo} />
        </View>
        <TouchableOpacity onPress={handleCartPress}>
          <Ionicons name="cart-outline" size={30} color="black" style={styles.shoppingCartIcon} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView}>
        <Text style={styles.newArrivalsText}>Offset</Text>
        <View style={styles.productContainer}>
          {productData.map((product) => (
            <ProductItem key={product.id} item={product} onPress={handlePress} />
          ))}
        </View>
      </ScrollView>

      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <Image source={require('../assets/home.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Brands')}>
          <Image source={require('../assets/tshirt.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Image source={require('../assets/user.png')} style={styles.logo} />
        </TouchableOpacity>
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  titleBar: {
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 20,
    paddingHorizontal: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  shoppingCartIcon: {
    width: 30,
    height: 30,
  },
  newArrivalsText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  productContainer: {
    flexDirection: 'column',
    alignItems: 'center',
    marginBottom: 20,
  },
  productItem: {
    alignItems: 'center',
    margin: 5,
  },
  productImage: {
    width: (Dimensions.get('window').width - 40) / 1,
    height: (Dimensions.get('window').width - 40) / 1,
  },
  productName: {
    fontSize: 16,
    marginTop: 5,
  },
  productPrice: {
    fontSize: 14,
    color: '#888',
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 10,
    paddingHorizontal: 20,
    position: 'absolute',
    bottom: 0,
  },
  scrollView: {
    flex: 1,
    width: '95%',
    marginTop: 20,
    marginBottom: 50,
  },
});

export default Offset;
