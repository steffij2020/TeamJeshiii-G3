import React, { useState } from 'react';
import { StyleSheet, View, Image, Dimensions, Text, TouchableOpacity } from 'react-native';

const Profile = ({ navigation }) => {
  const [orders, setOrders] = useState(0);
  const [cartItems, setCartItems] = useState(0);
  const [name, setName] = useState("Steffi J.");

  const navigateToSettings = () => {
    // Handle navigation to the Settings page
    console.log("Navigating to Settings page");
  };

  const navigateToFAQs = () => {
    // Handle navigation to the FAQs page
    console.log("Navigating to FAQs page");
  };

  return (
    <View style={styles.container}>
      <View style={styles.titleBar}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Image source={require('../assets/logo2.png')} style={styles.logo} />
          <Text style={styles.title}>Profile</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <Image source={require('../assets/shop.png')} style={styles.shoppingCartIcon} />
          {orders > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{orders}</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.profileContainer}>
        <Image source={require('../assets/profile.jpg')} style={styles.profilePicture} />
        <Text style={styles.profileName}>{name}</Text>
      </View>
      
      <View style={styles.optionsContainer}>
        <TouchableOpacity onPress={navigateToSettings}>
          <Text style={styles.option}>Edit Profile</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Faqs')}>
          <Text style={[styles.option, { marginTop: 20 }]}>FAQs</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('OrderHistory')}>
          <Text style={styles.option}>Order History</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('SavedItems')}>
          <Text style={styles.option}>Saved Items</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('WishList')}>
          <Text style={styles.option}>Wish List</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Notifs')}>
          <Text style={styles.option}>Notifications</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Cards')}>
          <Text style={styles.option}>Cards</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={() => navigation.navigate('Login')}>
        <Text style={styles.logoutButtonText}>Logout</Text>
      </TouchableOpacity>

      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <Image source={require('../assets/home.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Brands')}>
          <Image source={require('../assets/tshirt.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Image source={require('../assets/user.png')} style={styles.logo} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Profile;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start', 
    alignItems: 'center',
  },
  titleBar: {
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 20,
    paddingHorizontal: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  shoppingCartIcon: {
    width: 30,
    height: 30,
  },
  badge: {
    position: 'absolute',
    top: 5,
    right: 5,
    backgroundColor: 'red',
    borderRadius: 10,
    paddingHorizontal: 5,
    paddingVertical: 2,
  },
  badgeText: {
    color: 'white',
    fontWeight: 'bold',
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  profileContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  profilePicture: {
    width: 150,
    height: 150,
    borderRadius: 75,
  },
  profileName: {
    marginTop: 10,
    fontSize: 18,
    fontWeight: 'bold',
  },
  optionsContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  option: {
    fontSize: 16,
    color: 'black',
    marginBottom: 10,
  },
  logoutButton: {
    marginTop: 20,
    backgroundColor: 'lightgrey',
    paddingVertical: 5,
    paddingHorizontal: 40,
    borderRadius: 5,
    borderWidth: 1.5,
    backgroundColor: '#eee',
  },
  logoutButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'black',
    marginTop: 10,
    padding: 5,
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 10,
    paddingHorizontal: 20,
    position: 'absolute',
    bottom: 0,
  },
});
