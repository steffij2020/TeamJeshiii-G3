import React from 'react';
import { StyleSheet, View, Image, Dimensions, Text, TouchableOpacity, ScrollView } from 'react-native';
import Carousel from 'react-native-snap-carousel';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useCart } from './CartContext'; // Import useCart hook

const imagePaths = {
  logo: require('../assets/logo2.png'),
  home: require('../assets/home.png'),
  shop: require('../assets/shop.png'),
  tshirt: require('../assets/tshirt.png'),
  search: require('../assets/search.png'),
  user: require('../assets/user.png')
};

const carouselImages = [
  require('../assets/image1.jpg'),
  require('../assets/image2.png'),
  require('../assets/image3.jpg'),
  require('../assets/image4.jpg'),
  require('../assets/image5.jpg'),
  require('../assets/image6.png')
];

const productData = [
  { uri: require('../assets/product1.jpg'), name: 'Olive Hoodie', price: '3,500' },
  { uri: require('../assets/product2.jpg'), name: 'TW Thunder Mesh', price: '2,000' },
  { uri: require('../assets/product3.jpg'), name: 'CF Gray Hoodie', price: '3,000' },
  { uri: require('../assets/product4.jpg'), name: 'HLGNS Acid', price: '3,000' },
  { uri: require('../assets/product5.jpg'), name: 'HLGNS Jorts', price: '1,200' },
  { uri: require('../assets/product6.jpg'), name: 'Offset Shades', price: '600' }
];

const Home = () => {
  const navigation = useNavigation();
  const { addToCart } = useCart();

  const handleCartPress = () => {
    navigation.navigate('Cart');
  };

  const handleNavigation = (screen) => {
    navigation.navigate(screen);
  };

  const renderCarouselItem = ({ item }) => {
    return (
      <Image source={item} style={styles.carouselImage} />
    );
  };

  const handleAddToCart = (product) => {
    addToCart(product);
  };

  return (
    <View style={styles.container}>
      <View style={styles.titleBar}>
        <View style={styles.titleBarLeft}>
          <Image source={imagePaths.logo} style={styles.logo} />
          <Text style={styles.title}>Shop</Text>
        </View>
        <TouchableOpacity onPress={handleCartPress} style={styles.iconContainer}>
          <Ionicons name="cart-outline" size={36} color="black" />
        </TouchableOpacity>
      </View>
      
      <ScrollView style={styles.scrollView}>
        <Carousel
          data={carouselImages}
          renderItem={renderCarouselItem}
          sliderWidth={Dimensions.get('window').width}
          itemWidth={Dimensions.get('window').width}
          autoplay
          loop
          autoplayInterval={3000}
          style={styles.carousel}
        />
        <Text style={styles.newArrivalsText}>New Arrivals</Text>
        <View style={styles.productContainer}>
          {productData.map((product, index) => (
            <TouchableOpacity key={index} style={styles.productItem} onPress={() => handleAddToCart(product)}>
              <Image source={product.uri} style={styles.productImage} />
              <Text style={styles.productName}>{product.name}</Text>
              <Text style={styles.productPrice}>{product.price}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => handleNavigation('Home')}>
          <Image source={imagePaths.home} style={styles.navIcon} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleNavigation('Brands')}>
          <Image source={imagePaths.tshirt} style={styles.navIcon} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleNavigation('Profile')}>
          <Image source={imagePaths.user} style={styles.navIcon} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#fff'
  },
  titleBar: {
    backgroundColor: '#eee',
    width: '100%',
    paddingVertical: 20,
    paddingHorizontal: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  titleBarLeft: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold'
  },
  newArrivalsText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10
  },
  productContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 20
  },
  productItem: {
    alignItems: 'center',
    margin: 5
  },
  productImage: {
    width: (Dimensions.get('window').width - 40) / 3,
    height: (Dimensions.get('window').width - 40) / 3
  },
  productName: {
    fontSize: 16,
    marginTop: 5
  },
  productPrice: {
    fontSize: 14,
    color: '#888'
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#eee',
    width: '100%',
    paddingVertical: 10,
    paddingHorizontal: 20,
    position: 'absolute',
    bottom: 0
  },
  navIcon: {
    width: 50,
    height: 50,
  },
  carousel: {
    marginTop: 10
  },
  carouselImage: {
    width: '100%',
    height: 200
  },
  scrollView: {
    flex: 1,
    width: '90%',
    marginTop: 20,
    marginBottom: 50
  }
});

export default Home;
