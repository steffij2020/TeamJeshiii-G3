import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView, StyleSheet } from 'react-native';
import { useCart } from '../screens/CartContext';
import { CheckBox } from 'react-native-elements';

const CheckoutScreen = ({ totalPrice, navigation }) => {
  const { cartItems } = useCart();
  const [voucherCode, setVoucherCode] = useState('');
  const [applyVoucher, setApplyVoucher] = useState(false);
  const [selectedPaymentOption, setSelectedPaymentOption] = useState(null);

  const handleApplyVoucher = () => {
    // Logic to apply voucher
  };

  const handlePaymentOption = (option) => {
    setSelectedPaymentOption(option);
  };

  const handlePayment = () => {
    // Perform payment logic here
    // After successful payment, navigate back to CartScreen
    navigation.navigate('Success');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Checkout</Text>
      </View>
      
      <View style={styles.paymentOptionsContainer}>
        <TouchableOpacity
          style={[styles.paymentOptionButton, selectedPaymentOption === 'Cash on Delivery' && styles.selectedPaymentOption]}
          onPress={() => handlePaymentOption('Cash on Delivery')}>
         <Image source={require('../assets/cod.png')} style={styles.paymentOptionLogo} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.paymentOptionButton, selectedPaymentOption === 'GCash' && styles.selectedPaymentOption]}
          onPress={() => handlePaymentOption('GCash')}>
          <Image source={require('../assets/gcash.png')} style={styles.paymentOptionLogo} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.paymentOptionButton, selectedPaymentOption === 'PayPal' && styles.selectedPaymentOption]}
          onPress={() => handlePaymentOption('PayMaya')}>
         <Image source={require('../assets/paypal.png')} style={styles.paymentOptionLogo} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollContainer}>
        <View style={styles.orderItemsContainer}>
          <Text style={styles.ordersText}>Order Items</Text>
          {cartItems.map((item, index) => (
            <View key={index} style={styles.orderItem}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemPrice}>₱{(item.price * item.quantity).toFixed(2)}</Text>
            </View>
          ))}
        </View>

        <View style={styles.voucherContainer}>
          <CheckBox
            value={applyVoucher}
            onValueChange={(value) => setApplyVoucher(value)}
          />
          <Text style={styles.voucherText}>Apply Voucher</Text>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <Text style={styles.totalPrice}>Total: ₱{totalPrice.toFixed(2)}</Text>
        <TouchableOpacity style={styles.paymentButton} onPress={handlePayment}>
          <Text style={styles.paymentButtonText}>PROCEED TO PAYMENT</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
    paddingHorizontal: 15,
  },
  header: {
    borderBottomWidth: 1,
    borderBottomColor: '#000',
    paddingBottom: 10,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000',
  },
  paymentOptionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  paymentOptionButton: {
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 10,
    padding: 5,
    justifyContent: 'center',
    alignItems: 'center',
    width: '30%',
  },
  paymentOptionLogo: {
    width: 50,
    height: 50,
    resizeMode: 'contain',
  },
  selectedPaymentOption: {
    backgroundColor: '#000',
    borderColor: '#000',
  },
  scrollContainer: {
    flex: 1,
    marginBottom: 20,
  },
  orderItemsContainer: {
    marginBottom: 20,
  },
  ordersText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#000',
  },
  orderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  itemName: {
    fontSize: 16,
    color: '#000',
  },
  itemPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
  },
  voucherContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  voucherText: {
    fontSize: 16,
    marginLeft: 10,
    color: '#000',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#000',
    paddingTop: 10,
  },
  totalPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  paymentButton: {
    backgroundColor: '#FFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#000',
  },
  paymentButtonText: {
    fontSize: 16,
    color: '#000',
    fontWeight: 'bold',
  },
});

export default CheckoutScreen;