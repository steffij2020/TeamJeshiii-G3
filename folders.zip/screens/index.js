
import Login from "./login";
import Welcome from "./welcome";
import Signup from "./signup";

export {
    Login,
    Welcome,
    Signup
}
