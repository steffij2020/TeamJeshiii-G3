import React, { useState } from 'react';
import { StyleSheet, View, Image, Dimensions, Text, TouchableOpacity, ScrollView } from 'react-native';

const Faqs = ({ navigation }) => {
  const [expanded, setExpanded] = useState([]);

  const toggleFAQ = (index) => {
    const newExpanded = [...expanded];
    newExpanded[index] = !expanded[index];
    setExpanded(newExpanded);
  };

  const faqs = [
    {
      question: 'How do I place an order?',
      answer:
        '- Go to the SHOP section & browse through selection of available products\n' +
        '- Add & manage desired items into your cart\n' +
        '- Please double check the items in your cart as we would not be accepting cancellation of orders once your order is submitted/confirmed.\n' +
        '- Proceed to checkout and fill out the form before your screen\n' +
        '- Modes of payment: Debit Card / Credit Card or Gcash\n' +
        '- Wait for an email confirmation from our online sales rep and your orders will be prepared and will be shipped soon',
    },
    {
      question: 'What courier do you use when shipping items within the country?',
      answer: '- We use LBC for transactions outside Metro Manila, and Techno protocol Logistic Services for orders within Metro Manila.',
    },
    {
      question: 'How much is the shipping fee?',
      answer: '- The shipping fee will depend on your quantity of your order(s) and its weight. The starting price of the shipping fee will be 169PHP and will increase depending on the weight of your item(s) and location.',
    },
    {
      question: 'How many days will it take to receive my order(s)?',
      answer:
        '- You can expect to have your orders after 7-14 working days from the date of receiving your email confirmation.\n' +
        '- You may track your orders through the email confirmation that will be sent to you.\n' +
        'NOTE: your orders may take longer than expected come peak season',
    },
    {
      question: 'I still haven’t received my shipment. What do I do with this?',
      answer: '- What we can do is help you guys track your parcels and monitor its current location once the orders are shipped out.  - but with regards to the date on when you’ll receive the items ordered is already out of our control. For this matter, you can verify and ask for a follow-up of the parcel with the chosen courier.',
    },
    {
      question: 'What is your Return & Exchange Policy?',
      answer: '- Generally, only defective items or wrong order/s sent by our staff may be exchanged. But reasonable cases like wrong sizing can be an exception to the rule.\n- Once orders are confirmed, we cannot cancel it anymore. We do not accept refunds.',
    },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.titleBar}>
        <Image source={require('../assets/logo2.png')} style={styles.logo} />
        <Text style={styles.title}>FAQ's</Text>
      </View>
      <ScrollView style={styles.scrollContainer}>
        <View style={styles.content}>
          {faqs.map((faq, index) => (
            <TouchableOpacity key={index} onPress={() => toggleFAQ(index)} style={styles.faq}>
              <Text style={styles.faqTitle}>{faq.question}</Text>
              {expanded[index] && <Text style={styles.answerText}>{faq.answer}</Text>}
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <Image source={require('../assets/home.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Brands')}>
          <Image source={require('../assets/tshirt.png')} style={styles.logo} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Image source={require('../assets/user.png')} style={styles.logo} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Faqs;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  titleBar: {
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 20,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  scrollContainer: {
    flex: 1,
    width: '100%',
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  faq: {
    marginBottom: 20,
  },
  faqTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  answerText: {
    fontSize: 16,
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#eee',
    width: Dimensions.get('window').width,
    paddingVertical: 10,
    paddingHorizontal: 20,
    position: 'absolute',
    bottom: 0,
  },
});
