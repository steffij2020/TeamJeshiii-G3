import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useCart } from '../screens/CartContext'; // Import useCart hook

const Mnla3 = () => {
  const { addToCart } = useCart(); // Access addToCart function from CartContext

  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState(0);

  const handleAddToCart = () => {
    // Assuming you have a function addToCart in your context to add items to the cart
    const product = {
      name: 'ornate longsleeve tee in olive',
      price: 1270,
      image: require('../assets/mnla3.png'), // Replace with your product image source
      description: 'An opulent olive longsleeve tee adorned with intricate gold embroidery, exuding elegance and sophistication.',
      materials: 'Cotton, Synthetic fibers',
    };
    addToCart(product);
  };

  return (
    <View style={styles.container}>
      {/* Logo */}
      <Image source={require('../assets/haulygrail.png')} style={styles.logo} />

      <View style={styles.imageContainer}>
        <Image
          source={require('../assets/mnla3.png')} // Replace with your product image source
          style={[styles.productImage, { marginLeft: position.x, marginTop: position.y }]}
        />
      </View>

      {/* Additional text boxes */}
      <View style={styles.textContainer}>
        <Text style={styles.titleText}>ornate longsleeve tee in olive</Text>
        <Text style={styles.descriptionText}><Text style={{ fontWeight: 'bold' }}>Description:</Text> An opulent olive longsleeve tee adorned with intricate gold embroidery, exuding elegance and sophistication.</Text>
        <Text style={styles.materialsText}><Text style={{ fontWeight: 'bold' }}>Materials:</Text> Cotton, Synthetic fibers</Text>
      </View>

      <View style={styles.bottomContainer}>
        <View style={styles.priceContainer}>
          <Text style={styles.priceText}>Price: ₱1270</Text>
        </View>
        <TouchableOpacity style={styles.addToCartButton} onPress={handleAddToCart}>
          <Text style={styles.addToCartButtonText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: 200, // Adjust size as needed
    height: 100, // Adjust size as needed
    resizeMode: 'contain',
    position: 'absolute',
    top: 20,
  },
  imageContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  productImage: {
    width: 350, // Adjust as needed
    height: 370, // Adjust as needed
  },
  textContainer: {
    alignItems: 'flex-start', // Changed to flex-start
    marginBottom: 10,
    marginLeft: 20, // Adjust margin as needed
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  descriptionText: {
    fontSize: 12,
    marginBottom: 5,
  },
  materialsText: {
    fontSize: 12,
    marginBottom: 5,
  },
  bottomContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    marginLeft: 20, // Adjust margin as needed
  },
  priceContainer: {
    flex: 1,
    alignItems: 'flex-start', // Changed to flex-start
    marginRight: 10, // Adjust margin as needed
  },
  priceText: {
    fontSize: 20,
    fontWeight: 'bold', // Added fontWeight
  },
  addToCartButton: {
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  addToCartButtonText: {
    color: 'white',
    fontSize: 18,
  },
});

export default Mnla3;
